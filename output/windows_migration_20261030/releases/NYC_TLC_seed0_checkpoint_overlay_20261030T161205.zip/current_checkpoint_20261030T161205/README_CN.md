# NYC seed 0 Windows checkpoint overlay

Captured: 2026-10-30 16:12:05 CST

This overlay updates the earlier base bundle `NYC_TLC_dispatch_seed0_20261030T0734Z.zip` with the raw files for `EV_20240828_213000_q75` and the exact official `experiment_manifest.json` / `progress.jsonl` copies. The base ZIP is a historical 15:34 snapshot; apply this overlay after restoring that base.

## Current stop boundary

- The local process scan found no NYC runner. The experiment driver reported exit code 143.
- F1/D5 has 15 raw round traces and no official method-result file. Keep failed rounds and unknown usage as recorded; do not replay.
- F2/D8 has a completed raw trace with 13,449 input and 238 output tokens, but no official method-result file. Actual charge is unknown; do not replay.
- The official manifest and progress file remain byte-for-byte as stored, including their `running`/last-progress state. The independent stop record documents that the process has stopped; it does not invent a formal finish/result.

## Restore on Windows

1. Extract the base NYC migration ZIP into the Windows project copy.
2. Extract this overlay ZIP beside it.
3. From PowerShell, run `RESTORE_WINDOWS.ps1 -ProjectRoot <project-root>` to verify and merge the overlay.
4. Read `STOP_AND_MIGRATION_STATE.json` before any later run decision. This restore script only copies and verifies files; it does not start an experiment.

Official source files copied: `experiment_manifest.json` SHA-256 `8f2ccdb0026330939e52f216a85584ebb7ec96bbccfaa58778525483702ce566`; `progress.jsonl` SHA-256 `01fb1dfec8ba9ff7a64b837fe43208baaef4649e075c58c6e41203b7e44dc2f6`. Per-file hashes are in `SHA256SUMS.txt`.
