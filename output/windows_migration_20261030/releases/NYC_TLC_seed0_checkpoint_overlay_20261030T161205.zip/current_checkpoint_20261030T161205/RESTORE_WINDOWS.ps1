param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectRoot
)
$ErrorActionPreference = 'Stop'
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$OverlayRoot = Join-Path $PackageRoot 'project_root_overlay'
$ChecksumFile = Join-Path $PackageRoot 'SHA256SUMS.txt'
if (-not (Test-Path -LiteralPath $OverlayRoot -PathType Container)) { throw "Missing overlay: $OverlayRoot" }
if (-not (Test-Path -LiteralPath $ChecksumFile -PathType Leaf)) { throw "Missing checksum file: $ChecksumFile" }
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
foreach ($line in Get-Content -LiteralPath $ChecksumFile) {
    if ($line -match '^([0-9a-f]{64})  (.+)$') {
        $expected = $Matches[1]
        $relative = $Matches[2].Replace('/', [IO.Path]::DirectorySeparatorChar)
        $source = Join-Path $OverlayRoot $relative
        if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing package file: $relative" }
        $actual = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne $expected) { throw "SHA-256 mismatch: $relative" }
    }
}
foreach ($line in Get-Content -LiteralPath $ChecksumFile) {
    if ($line -match '^([0-9a-f]{64})  (.+)$') {
        $relative = $Matches[2].Replace('/', [IO.Path]::DirectorySeparatorChar)
        $source = Join-Path $OverlayRoot $relative
        $destination = Join-Path $ProjectRoot $relative
        $parent = Split-Path -Parent $destination
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
        Copy-Item -LiteralPath $source -Destination $destination -Force
    }
}
Write-Host 'Checkpoint overlay restored and verified. No experiment was started.'
