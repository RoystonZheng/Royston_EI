# R4 provider failure audit

Read-only snapshot captured 2026-10-27T13:22:42.226294+00:00.

- Source manifest SHA-256: `e7aba82c8f4edc342d733590cf2593c926c73bd12f6e945201198ab49ea40ef4`
- Routeable denominator: 129
- Registered requests at snapshot: 4920
- Failed task count: 12
- Finding: all terminal failed tasks in this snapshot have a terminal 429 event; stream disconnections also occurred in 4 tasks.
- Each linked raw trace is retained in the experiment root. No model requests were made to produce this sidecar.
