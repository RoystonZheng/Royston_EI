# R4 trace-finalization and 429 continuation repair

This is a local diagnostic snapshot. No model request was sent by the code changes or their tests.

## Findings

- A recovered task stopped at finalization because the finalizer derived the trace filename from its local request number. The attempt ledger pointed to `traces/r4_step_0009.jsonl` for local request 8 and included its SHA-256. The trace existed; the finalizer looked for the missing `r4_step_0008.jsonl`.
- The finalizer now uses the attempt's recorded trace path and verifies its hash. The old failing run now has a correct partial audit; it remains incomplete and request 8 remains delivery/usage unknown.
- Some route tasks stop on an explicit Codex CLI `429 Too Many Requests`. The chunk driver now checks the exact failed task and hash-bound trace, waits 180 seconds, then continues on a different pending task. It never replays the failed/unknown request. Other errors still stop for diagnosis.
- The R4 deterministic local directed-edge validator is already in use; inspected accepted steps passed it. Failures listed here are rate-limit interruptions, not illegal route actions.
- Current `r4-step-v3` uses a compact JSON map representation, but because the session mode is `ephemeral_per_request`, the map is resent at every movement: one inspected prompt was 20,780 bytes / 18,334 input tokens / 0 cached input tokens. Reducing that repeated input is a valid next-version efficiency improvement, but changing the active batch would change its frozen input condition.

## Verification

`test_429_continuation_policy.py` passed: explicit hash-matching 429 is recognized; non-429 provider errors do not trigger auto-continue; modified traces fail closed. The finalizer test also passed trace mapping, unknown-usage classification, invocation-count alignment, and hash integrity on the previously failing local run. Python byte-compilation passed.

## Checkpoint

See `repair_record.json` and the immutable `root_manifest_checkpoint_20261027T144150Z.json` / `worker01_manifest_checkpoint_20261027T144210Z.json` snapshots for exact hashes and timestamped counts. The root index was refreshed from worker manifests; root and worker counters are not to be added together. The active worker remains on the no-cap, single-request-at-a-time driver.
