import hashlib, importlib.util, json, tempfile
from pathlib import Path

PROJECT = Path('/Users/didi/Library/Application Support/CodexR4Formal20261027')
DRIVER = PROJECT / 'scripts/run_r4_formal_chunk_driver.py'
spec = importlib.util.spec_from_file_location('r4_driver', DRIVER)
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

# Live failed task: explicit 429 must be recognized from its hash-bound trace.
worker = PROJECT / 'outputs/route_layer/r4_codex_formal_batch_20261027_v2/parallel_workers/worker_01'
failed_run = worker / 'tasks/seed_9/formal-task-0009-feasible/run_000'
manifest = {'current_task_id':'formal-task-0009-feasible','tasks':[{'task_id':'formal-task-0009-feasible','status':'failed','output_dir':str(failed_run)}]}
evidence = mod.confirmed_provider_429(worker, manifest)
assert evidence and evidence['task_id'] == 'formal-task-0009-feasible'
assert evidence['usage_available'] is False
assert evidence['request_number'] == 16

# Synthetic negative check: a different provider error must not trigger cooldown auto-continue.
with tempfile.TemporaryDirectory() as temp:
    batch = Path(temp); run = batch / 'task'; run.mkdir()
    trace = run / 'trace.jsonl'
    raw = b'{"type":"error","message":"provider unavailable"}\n'
    trace.write_bytes(raw)
    state = {'status':'stopped_request_error','attempts':[{'request_number':1,'provider_record':{
        'trace_jsonl_path':str(trace),'trace_jsonl_sha256':hashlib.sha256(raw).hexdigest(),
        'usage_available':False}}]}
    (run/'state.json').write_text(json.dumps(state))
    manifest = {'current_task_id':'task-1','tasks':[{'task_id':'task-1','status':'failed','output_dir':str(run)}]}
    assert mod.confirmed_provider_429(batch, manifest) is None
    raw429 = b'{"type":"error","message":"429 Too Many Requests"}\n'
    trace.write_bytes(raw429)
    state['attempts'][0]['provider_record']['trace_jsonl_sha256'] = hashlib.sha256(raw429).hexdigest()
    (run/'state.json').write_text(json.dumps(state))
    assert mod.confirmed_provider_429(batch, manifest) is not None
    trace.write_bytes(raw429 + b' ')
    assert mod.confirmed_provider_429(batch, manifest) is None
print('PASS live 429 recognized only with matching trace hash')
print('PASS non-429 provider error does not trigger auto-continue')
print('PASS trace tampering fails closed')
