# R4 EV v2 partial-prefix audit

This immutable offline sidecar recalculates energy for the 30-edge legally accepted prefix of `task-0004-0008`. The route did not reach pickup or dropoff and is not a completed trip.

- Status: `offline_recalculated_partial_legal_prefix`
- Distance / duration: 3000 m / 358.114 s
- EV v2 signed-net prefix estimate: 0.375614683 kWh (propulsion 0.437971294 − regen 0.141937603 + auxiliary 0.079580993)
- Grade data is missing; this model result is an estimate from frozen road-edge conditions, not a measured vehicle value.
- Request 31 trace records HTTP 429; usage is absent and the source audit marks delivery/usage unknown. It was not replayed.
- Full route energy and cash cost remain null. No model calls or route selection reruns were made.

The JSON binds the source map, preflight, state, final audit, failed attempt, all 31 per-request trace/attempt hashes, and the EV profile hash.
