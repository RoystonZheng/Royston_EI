# R4 恢复检查点

- 捕获时间：2026-10-29T23:53:20.972537+08:00
- parent：`paused_at_parallel_checkpoint`，SHA-256 `1306efcd4cd9a13eaa7d8ea31d0b1e45263a3525432844761e232b94fc2f1d01`，请求计数 `12073`。
- 任务状态：`{'route_complete': 58, 'outcome_unknown': 10, 'failed': 12, 'ready': 25, 'pending': 24}`；请求级 delivery/usage unknown：26。
- 在途请求：0；R4 runner：0。
- EV2 source-run集合：58条sidecar源 run 与当前58条 route_complete 目录完全匹配；审计见 [parent_set_reconciliation_20261029T235320CST.json](../../r4_ev2_payload_phase_source_binding_20261029T234954CST/parent_set_reconciliation_20261029T235320CST.json)。
- source binding：[`source_binding_addendum.json`](../../r4_ev2_payload_phase_source_binding_20261029T234954CST/source_binding_addendum.json)，SHA-256 `29a8611d596e1d000d2df8c649c081cd36774d0d8ec2d76838101f96374ee5b3`；系事后provenance绑定，历史执行字节身份未被原manifest记录。
- 实时HTML索引 SHA-256：`dba96505812a00c290215ad5e7edd253f07d7802ad6c8026b1e8cc9f99c53777`。
- 本次只读状态、刷新索引及生成审计文件；未发模型请求、未重跑路线。
