# R4 EV v2 partial-prefix audit

Task `task-0007-0004` stopped before pickup/dropoff. This offline sidecar recalculates only its 28-edge legal prefix.

- Prefix: 2800 m / 306.522 s
- EV v2 estimated signed-net: 0.333386776 kWh = propulsion 0.384068209 − regeneration 0.118797475 + auxiliary 0.068116042
- Missing grade and edge-condition estimate; not a full route, completed-trip result, or vehicle measurement. Cash cost and full-route energy stay null.
- Request 29 trace: HTTP 429; no usage event, delivery/usage uncertainty preserved, not replayed.
- 0 model calls and 0 route-selection reruns. Source and all per-request hashes are in the JSON.
