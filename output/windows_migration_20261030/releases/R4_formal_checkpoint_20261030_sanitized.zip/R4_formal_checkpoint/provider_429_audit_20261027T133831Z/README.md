# R4 provider failure audit

Read-only snapshot at 2026-10-27T13:38:31.766538+00:00.
- Root manifest SHA-256: `061f12c47126b125cd9c48b4750207fd0fe156b19dcb81b9083c9fea1b2462f4`
- Registered requests: 4970
- Terminal failed tasks: 17; all have a terminal 429 event.
- Unique delivery-unknown requests: 19; preserved without replay.
- Prefix energy is partial; no model requests were made to produce this sidecar.
