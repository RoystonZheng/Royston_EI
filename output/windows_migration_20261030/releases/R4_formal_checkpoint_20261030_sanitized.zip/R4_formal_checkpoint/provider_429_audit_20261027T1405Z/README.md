# R4 429 失败审计 v4

- 129 task frozen denominator; latest snapshot has 19 completed routes, 19 failed tasks, 85 pending, 6 ready, 19 request delivery unknown.
- All 19 failed traces record HTTP 429; no failure is classified as a route validator violation.
- Prefix metrics are partial legal-prefix estimates only, never full-route results. Failed calls have no CLI usage record. Unknown requests remain preserved and are not replayed.
- 0 model calls were made for this offline audit. Original v3 snapshot was preserved.
- See `index.html` for task rows and direct trace/audit links; `audit.json` binds source trace hashes and the root manifest snapshot SHA-256 `a3bc447d28c382a6f7dae4386a115f9a7826cca0f64b5eb54e89fdcf32914e71`.
