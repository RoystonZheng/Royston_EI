#!/usr/bin/env python3
"""Keep the authorized R4 batch running in one-request checkpoints.

Interrupted requests are preserved as unknown and never replayed. Independent
frozen tasks continue; the fixed denominator remains in the batch manifest.
"""
import hashlib
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

BATCH_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BATCH_DIR.parents[2]
RUNNER = PROJECT_ROOT / "scripts" / "run_r4_codex_formal_batch.py"
MANIFEST = BATCH_DIR / "manifest.json"
PILOT = PROJECT_ROOT / "outputs" / "route_layer" / "r4_codex_formal_task9_pilot_20261027_v3" / "final_audit.json"
LOG = BATCH_DIR / "chunk_driver.jsonl"
REQUEST_LIMIT = 66048
USAGE_BASELINE = 39
# The user's latest instruction removes local shared-usage percentage stops.
# Leave enforcement to actual platform limits; do not stop the formal batch at 100%.
USAGE_STOP = None


def read_manifest():
    return json.loads(MANIFEST.read_text(encoding="utf-8"))


def log(event):
    event["at_utc"] = datetime.now(timezone.utc).isoformat()
    with LOG.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")


def defer_unknown_inflight(manifest):
    flight = manifest.get("in_flight")
    if not flight:
        return False
    task = next((item for item in manifest["tasks"] if item["task_id"] == flight.get("task_id")), None)
    if task is None or not task.get("output_dir"):
        return False
    output = Path(task["output_dir"])
    state_path = output / "state.json"
    if not state_path.exists():
        return False
    state = json.loads(state_path.read_text(encoding="utf-8"))
    if state.get("status") != "request_in_progress":
        return False
    expected = int(flight.get("expected_request_number", int(state.get("new_requests_used", 0)) + 1))
    trace = output / "traces" / ("r4_step_{0:04d}.jsonl".format(expected))
    final = output / "traces" / ("r4_step_{0:04d}.final.json".format(expected))
    attempt = output / ("attempt_{0:02d}.json".format(len(state.get("attempts", [])) + 1))
    trace_sha = hashlib.sha256(trace.read_bytes()).hexdigest() if trace.exists() else None
    unknown = dict(flight)
    unknown.update({
        "status": "outcome_unknown_no_retry",
        "trace_path": str(trace.relative_to(BATCH_DIR)) if trace.exists() else None,
        "trace_sha256": trace_sha,
        "final_artifact_exists_without_state_commit": final.exists(),
        "attempt_artifact_exists_without_state_commit": attempt.exists(),
        "recorded_successful_requests": manifest.get("model_requests_used", 0),
        "provider_usage_available": False,
    })
    prior = manifest.get("unresolved_in_flight")
    items = prior if isinstance(prior, list) else ([prior] if prior else [])
    items.append(unknown)
    manifest["unresolved_in_flight"] = items
    manifest["requests_with_unknown_delivery"] = len(items)
    manifest.pop("in_flight", None)
    task["status"] = "outcome_unknown"
    task["error"] = "request_interrupted_without_terminal_response_or_usage; preserved_without_automatic_replay"
    manifest["status"] = "paused_at_checkpoint_unknown_tasks_deferred"
    manifest.setdefault("events", []).append({
        "event": "deferred_unknown_task_to_continue_independent_tasks",
        "task_id": task["task_id"],
        "request_number": expected,
        "requests_reconciled": 0,
        "trace_sha256": trace_sha,
        "at_utc": datetime.now(timezone.utc).isoformat(),
        "details": "No terminal response or usage; no replay. Frozen task denominator remains unchanged.",
    })
    manifest["updated_at_utc"] = datetime.now(timezone.utc).isoformat()
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    log({"event": "unknown_request_deferred", "task_id": task["task_id"], "request_number": expected, "trace_sha256": trace_sha})
    return True


def main():
    log({"event": "driver_started", "request_limit": REQUEST_LIMIT, "usage_baseline_percent": USAGE_BASELINE, "usage_stop_percent": USAGE_STOP})
    while True:
        manifest = read_manifest()
        runnable = [item for item in manifest["tasks"] if item.get("status") in {"pending", "ready", "active", "budget_paused"}]
        if not runnable:
            log({"event": "driver_stopped_no_runnable_tasks", "status": manifest.get("status"), "unknown_tasks": [item["task_id"] for item in manifest["tasks"] if item.get("status") == "outcome_unknown"]})
            return 0
        cmd = [
            sys.executable, str(RUNNER), "--execute",
            "--output-dir", str(BATCH_DIR),
            "--request-limit", str(REQUEST_LIMIT),
            "--usage-baseline-percent", str(USAGE_BASELINE),
            "--usage-stop-percent", str(USAGE_STOP),
            "--pilot-audit", str(PILOT),
        ]
        started = time.monotonic()
        runner_log = BATCH_DIR / "chunk_runner.log"
        try:
            with runner_log.open("a", encoding="utf-8") as handle:
                process = subprocess.Popen(cmd, cwd=str(PROJECT_ROOT), stdout=handle, stderr=subprocess.STDOUT)
                while process.poll() is None:
                    print("R4 runner heartbeat; requests={0}; task={1}".format(
                        read_manifest().get("model_requests_used"), read_manifest().get("current_task_id")
                    ), flush=True)
                    time.sleep(8)
                returncode = process.returncode
        except Exception as error:
            log({"event": "runner_process_error", "error": repr(error)})
            return 2
        manifest = read_manifest()
        if manifest.get("in_flight") and defer_unknown_inflight(manifest):
            continue
        status = manifest.get("status")
        log({
            "event": "runner_chunk_finished",
            "returncode": returncode,
            "status": status,
            "model_requests_used": manifest.get("model_requests_used"),
            "route_complete_count": sum(item.get("status") == "route_complete" for item in manifest["tasks"]),
            "current_task_id": manifest.get("current_task_id"),
            "elapsed_sec": round(time.monotonic() - started, 3),
        })
        print("R4 chunk complete; status={0}; requests={1}; routes={2}".format(
            status, manifest.get("model_requests_used"),
            sum(item.get("status") == "route_complete" for item in manifest["tasks"])
        ), flush=True)
        if returncode != 0:
            return returncode or 1
        if status == "paused_at_request_chunk_limit":
            time.sleep(1)
            continue
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
