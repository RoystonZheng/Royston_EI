# R4 terminal 429 failure audit

This sidecar classifies the seven terminal failures from their preserved raw CLI traces. It does not alter source runs or manifests and makes no claim about provider billing. Request-outcome-unknown records remain a separate category and are not replayed.

- Audit: `audit.json`
- Source manifest snapshot SHA-256: `d9fe3e32a7c90811ca5762ea15791385d91a5d1f118330d2082e9b4a711e4678`
- Model requests for this audit: 0
