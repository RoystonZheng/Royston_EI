# R4 正式批次迁移检查点（脱敏版）

本包保留检查点状态、任务结果与进度数据，并剔除原始模型 trace、prompt、回放 HTML、日志和逐任务 manifest。
因此它不是原始 trace 的逐字节副本，不足以重放或归因任何 delivery/usage-unknown 请求。原始完整目录仍保留在本机迁移检查点。
恢复前必须先核对包内 `R4_migration_summary.json`、SHA256SUMS 和本机完整 checkpoint；不要清除 stop/halt 状态或重放未知请求。
该批次矩阵曾有 route_complete/failed/outcome_unknown/ready/skipped 多种状态，正式实验未完成。
