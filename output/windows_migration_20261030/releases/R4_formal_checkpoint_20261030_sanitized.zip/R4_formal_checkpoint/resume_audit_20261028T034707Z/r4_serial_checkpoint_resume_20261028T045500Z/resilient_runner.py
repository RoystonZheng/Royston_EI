#!/usr/bin/env python3
"""Fail-closed stub: this AppSupport R4 branch is quarantined.
Preserved original source is in quarantined_no_cap_sources/.
No model calls may be started from this branch.
"""
raise SystemExit("R4 AppSupport legacy branch quarantined; no model requests allowed")
