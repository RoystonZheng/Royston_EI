#!/usr/bin/env python3
"""Fail-closed quarantine: this legacy R4 launcher lacks the direct 100 percent per-request usage gate."""
import sys
print("blocked_legacy_r4_launcher_requires_fresh_pre_post_usage_and_one_request_gate", file=sys.stderr)
raise SystemExit(78)
