# R4 provider failure audit

Read-only snapshot at 2026-10-27T13:28:42.443636+00:00.
- Source root manifest SHA-256: `597475b486add8eee0308b433c7e04b2a826b47d75d9278128703e1987c745ce`
- Requests registered: 4940
- Terminal failed tasks: 13; all have a terminal 429 event.
- Unique delivery-unknown requests: 19; preserved without replay.
- No model requests were made to create this sidecar.
