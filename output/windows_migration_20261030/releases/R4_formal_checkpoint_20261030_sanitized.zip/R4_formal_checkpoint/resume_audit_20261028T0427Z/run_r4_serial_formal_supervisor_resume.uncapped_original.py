#!/usr/bin/env python3
"""Continue frozen R4 shards serially without replaying failed or unknown requests."""

import argparse
import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from run_r4_formal_chunk_driver import confirmed_provider_429, read_manifest


WORKER_ORDER = [
    "worker_00", "worker_01", "worker_02", "worker_03",
    "worker_recovery", "worker_recovery_addendum", "worker_recovery_addendum2",
]
RUNNABLE = {"pending", "ready", "active", "budget_paused"}


def stamp():
    return datetime.now(timezone.utc).isoformat()


def append_event(path, event):
    event["at_utc"] = stamp()
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")


def driver_processes(batch_root):
    try:
        output = subprocess.run(
            ["ps", "-axo", "pid=,command="], capture_output=True,
            text=True, check=True,
        ).stdout
    except subprocess.CalledProcessError:
        return []
    marker = str(batch_root.resolve())
    return [
        line.strip() for line in output.splitlines()
        if "run_r4_formal_chunk_driver.py" in line
        and marker in line
        and "run_r4_serial_formal_supervisor.py" not in line
    ]


def runnable_tasks(manifest):
    return [task for task in manifest.get("tasks", []) if task.get("status") in RUNNABLE]


def refresh_root(project_root, batch_root, log_path):
    command = [
        sys.executable,
        str(project_root / "scripts" / "r4_parallel_formal_batch.py"),
        "--batch-root", str(batch_root), "--refresh-once",
    ]
    with log_path.open("a", encoding="utf-8") as handle:
        result = subprocess.run(command, cwd=project_root, stdout=handle, stderr=subprocess.STDOUT)
    return result.returncode


def run_worker(project_root, batch_root, pilot_audit, worker_id, baseline, log_path):
    worker_root = batch_root / "parallel_workers" / worker_id
    manifest_path = worker_root / "manifest.json"
    manifest = read_manifest(manifest_path)
    pending = runnable_tasks(manifest)
    if not pending:
        append_event(log_path, {"event": "worker_skipped_no_runnable_tasks", "worker_id": worker_id,
                                "status": manifest.get("status")})
        return True

    if manifest.get("status") == "stopped_task_finalization_error":
        append_event(log_path, {"event": "supervisor_stopped_finalization_error", "worker_id": worker_id,
                                "task_id": manifest.get("current_task_id")})
        return False
    if manifest.get("status") == "stopped_provider_or_tool_contract_failure":
        if not confirmed_provider_429(worker_root, manifest):
            append_event(log_path, {"event": "supervisor_stopped_unclassified_provider_error",
                                    "worker_id": worker_id, "task_id": manifest.get("current_task_id")})
            return False
        # The prior task is terminal and excluded from RUNNABLE; only independent work follows.
        evidence = confirmed_provider_429(worker_root, manifest)
        event_name = (
            "confirmed_429_resume_independent_shard_tasks"
            if evidence["failure_type"] == "http_429"
            else "confirmed_capacity_resume_independent_shard_tasks"
        )
        append_event(log_path, {"event": event_name, "worker_id": worker_id,
                                **evidence, "cooldown_seconds": 180,
                                "failed_task_replayed": False})
        time.sleep(180)

    while True:
        active = driver_processes(batch_root)
        if active:
            append_event(log_path, {"event": "waiting_for_existing_single_driver", "worker_id": worker_id,
                                    "process_count": len(active)})
            time.sleep(10)
            continue

        command = [
            sys.executable,
            str(project_root / "scripts" / "run_r4_formal_chunk_driver.py"),
            "--batch-dir", str(worker_root),
            "--project-root", str(project_root),
            "--request-limit", "none",
            "--usage-baseline-percent", str(baseline),
            "--usage-stop-percent", "none",
            "--max-new-requests-per-invocation", "none",
            "--pilot-audit", str(pilot_audit),
        ]
        append_event(log_path, {"event": "worker_driver_started", "worker_id": worker_id,
                                "runnable_task_count": len(runnable_tasks(read_manifest(manifest_path))),
                                "project_request_cap": None, "usage_stop_percent": None,
                                "max_new_requests_per_invocation": None})
        with (worker_root / "serial_runner.log").open("a", encoding="utf-8") as output:
            process = subprocess.Popen(command, cwd=project_root, stdout=output, stderr=subprocess.STDOUT)
            while process.poll() is None:
                m = read_manifest(manifest_path)
                append_event(log_path, {"event": "worker_heartbeat", "worker_id": worker_id,
                                        "status": m.get("status"),
                                        "model_requests_used": m.get("model_requests_used"),
                                        "current_task_id": m.get("current_task_id")})
                time.sleep(30)
            returncode = process.returncode

        manifest = read_manifest(manifest_path)
        append_event(log_path, {"event": "worker_driver_exited", "worker_id": worker_id,
                                "returncode": returncode, "status": manifest.get("status"),
                                "model_requests_used": manifest.get("model_requests_used"),
                                "runnable_task_count": len(runnable_tasks(manifest))})
        if refresh_root(project_root, batch_root, log_path) != 0:
            append_event(log_path, {"event": "root_refresh_failed", "worker_id": worker_id})
            return False
        if returncode != 0:
            return False
        if not runnable_tasks(manifest):
            return True
        evidence = (
            confirmed_provider_429(worker_root, manifest)
            if manifest.get("status") == "stopped_provider_or_tool_contract_failure"
            else None
        )
        if evidence:
            event_name = (
                "confirmed_429_continue_after_cooldown"
                if evidence["failure_type"] == "http_429"
                else "confirmed_capacity_continue_after_cooldown"
            )
            append_event(log_path, {"event": event_name, "worker_id": worker_id,
                                    "task_id": manifest.get("current_task_id"),
                                    "failure_type": evidence["failure_type"],
                                    "trace_sha256": evidence["trace_sha256"],
                                    "cooldown_seconds": 180, "failed_task_replayed": False})
            time.sleep(180)
            continue
        append_event(log_path, {"event": "supervisor_stopped_runnable_tasks_remain_after_non_429_error",
                                "worker_id": worker_id, "status": manifest.get("status"),
                                "task_id": manifest.get("current_task_id")})
        return False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--batch-root", type=Path, required=True)
    parser.add_argument("--pilot-audit", type=Path, required=True)
    parser.add_argument("--usage-baseline-percent", type=int, required=True)
    parser.add_argument("--plan-only", action="store_true")
    args = parser.parse_args()
    project_root = args.project_root.resolve()
    batch_root = args.batch_root.resolve()
    pilot_audit = args.pilot_audit.resolve()
    log_path = batch_root / "parallel_workers" / "serial_supervisor.jsonl"

    plan = []
    for worker_id in WORKER_ORDER:
        path = batch_root / "parallel_workers" / worker_id / "manifest.json"
        if not path.is_file():
            continue
        manifest = read_manifest(path)
        plan.append({"worker_id": worker_id, "status": manifest.get("status"),
                     "runnable_tasks": len(runnable_tasks(manifest)),
                     "request_count": manifest.get("model_requests_used", 0)})
    if args.plan_only:
        print(json.dumps({"plan_only_no_model_requests": True, "workers": plan}, ensure_ascii=False, indent=2))
        return 0

    append_event(log_path, {"event": "serial_supervisor_started", "workers": plan,
                            "project_request_cap": None, "usage_stop_percent": None})
    for item in plan:
        if item["runnable_tasks"] == 0:
            continue
        ok = run_worker(project_root, batch_root, pilot_audit, item["worker_id"],
                        args.usage_baseline_percent, log_path)
        if not ok:
            append_event(log_path, {"event": "serial_supervisor_stopped_for_diagnosis",
                                    "worker_id": item["worker_id"]})
            return 1
    refresh_root(project_root, batch_root, log_path)
    append_event(log_path, {"event": "serial_supervisor_all_shards_terminal_or_skipped"})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
