# NYC TLC 派单实验 Windows 迁移包

创建时间：2026-10-30 15:34 CST。

## 状态

用户已要求停止实验并准备迁移 Windows。此包只保存和搬运证据，不会启动 runner。seed 0 正式 EV2 审计为 **472/630 有效结果，158 缺失，0 无效**。NYC 是真实 TLC 订单需求映射到 zone-level OD cost proxy，不是街道级路网。

F4 的 `EV_20240817_225000_q50` 中 D0/D1/D2/D6/D7/D8 有正式结果；D5 没有官方结果文件。D5 原始记录中第 5 轮是 HTTP 429，第 7 轮只有 final JSON、对应 JSONL 为空，因此均不重试/重放。已完成 D5 turn 的 trace usage 为 153,361 input（cached 50,688）、1,100 output（reasoning 464，已包含于 output）；实际账户扣费未知。正式 progress.jsonl 仍以 D5 start 为末条记录，官方 manifest 的 status 字段仍为 running；不要据此直接运行原 batch 命令，也不要手工补造 finish/result。

## 内容

- `project_root_overlay/`：可按相对路径合并回项目根目录的文件。包括全部 472 个官方审计结果、审计引用的 1,247 个唯一 Codex trace、D5 未决轮次痕迹、正式 manifest/progress、三个官方审计快照、v5 离线侧车，以及本批次输入、代码模块和审计脚本。
- `STOP_AND_MIGRATION_STATE.json`：停机决定、当前进程核验、D5轮次与usage边界、矩阵覆盖、sidecar状态。
- `SHA256SUMS.txt` 和 `bundle_manifest.json`：逐文件完整性清单。

包内没有 Codex/API 凭据，也没有 `*.prompt.txt`。trace和模型输出属于实验内部原始材料，请仅在个人受控 Windows 环境使用，勿公开上传。

## Windows 使用

1. 将 zip 解压到 Windows 项目副本。先按 `SHA256SUMS.txt` 校验文件。
2. `project_root_overlay/` 下的路径相对于原项目根目录；需要时按相对路径合并回完整项目。
3. 当前宿主为 macOS、Python 3.9.6。Windows 需自行安装兼容 Python、依赖和 Codex CLI，并由用户在本机完成 Codex 登录；凭据不会随包迁移。
4. 此包是冻结检查点。D5 的 429/unknown 均保留原状；只有用户之后明确要求恢复实验，才应先做 Windows 环境预检和单元恢复设计。现在不要启动 runner、不要重放请求、不要改写正式结果或原 manifest/progress。

EV2账本和词典序目标以随包代码、输入及审计快照为准；time-money v5 是离线sidecar，不代表在线selector。
