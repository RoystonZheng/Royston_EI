# AI Native DevKit

AI Native DevKit 是滴滴内部面向 Coding Agent 的研发流程插件。Current 0.4.0 让 Clarify
复用 Superpowers 6.3.0 的需求理解行为，在访谈完成后提交一份最小 Git requirements 记录，
并把后续回合审批绑定到精确的 path、commit 和 blob identity；Design 只读取显式提供的已批准
`RequirementDocRef`。旧 checkpoint/result 澄清契约已移除，仓库外历史用户状态保持原样但不再支持。
`0.3.0` 新增的插件内置 Collector Hook、自动 Execution Trace 和验证通过后触发的 Docs Hook，
以及 Init 的 `0.2.3` 跨仓隔离和跨回合确认门禁继续保留。
Trace 进一步通过代码边界记录阶段起止、确认请求/结果以及 Init 文档变更明细，不要求 Agent
输出内部路由或日志说明。路线必需阶段、确认、验证及 Docs 结果默认由完成门禁校验；用户明确跳过阶段或忽略阻塞项时，
Runtime 记录限定范围的例外并继续剩余流程，保留未执行和失败的事实；
Docs 实际变更路径由私有前后快照自动得出。Handoff 接手文档由用户自行管理；插件不再提供
相关 Skill、扫描、迁移提示、审批或路径拦截，也不询问是否更新。已有文档保持原样，旧 Trace 仍可读取。

新生成的文档默认使用简体中文；用户明确要求英文时按其要求输出，技术标识符保持原样。
Init 仓库修订快照和需求写入保护快照只纳入 Git 已跟踪内容，排除所有未跟踪文件，
包括被忽略的依赖和构建产物，避免这些文件触发快照大小限制。

0.4.0 implemented：Superpowers-aligned requirement discovery and the exact
Git requirement handoff are Current.

## 仓库结构

```text
.
├── AGENTS.md                         # 贡献、契约与文档边界
├── .agents/plugins/marketplace.json  # Codex Marketplace 配置
├── plugins/ai-native-devkit/         # 插件清单、Skills、模板和校验脚本
├── docs/                             # 当前架构、契约、工作流和 ADR
├── scripts/validate_all.py           # 完整校验入口
└── tests/                            # 契约和回归测试
```

## 安装

```bash
git clone git@git.xiaojukeji.com:ai-native/ai-native-devkit.git
cd ai-native-devkit
python3 -m pip install -r requirements-dev.txt
python3 scripts/validate_all.py
codex plugin marketplace add "$(pwd)"
codex plugin add ai-native-devkit@ai-native-devkit
```

插件安装后，使用 `$coding-sop` 处理完整研发任务，也可以显式调用 `$sop-init`、`$sop-clarify`、
`$sop-design`、`$sop-plan`、`$sop-execute`、`$sop-debug`、`$diagnosing-bugs`、`$sop-verify`、
`$sop-sync-docs`。完整 Debug 流程通过 `$sop-debug` 自动调用内置的
`$diagnosing-bugs`。

## 开发验证

要求 Python 3.9 或更高版本。在提交前运行：

```bash
python3 -m pip install -r requirements-dev.txt
python3 scripts/validate_all.py
```

插件详细说明、版本边界和本地更新方式见
[`plugins/ai-native-devkit/README.md`](plugins/ai-native-devkit/README.md)。第三方来源与许可见
[`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md)。
