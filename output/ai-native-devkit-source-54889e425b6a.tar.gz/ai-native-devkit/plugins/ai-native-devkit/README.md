# AI Native DevKit

AI Native DevKit 是一个面向 Codex 的结构化软件交付插件。Current 0.4.0 让 Clarify 复用
Superpowers 6.3.0 的需求理解行为，提交一份最小 Git requirements 记录，并通过 Execution
Trace 将后续回合审批绑定到精确 Git identity；Design 只读取显式提供的已批准
`RequirementDocRef`。`0.3.0` 的插件内置 Collector Hook、自动 Execution Trace 和验证后的
Docs Hook，以及 Init 的 `0.2.3` 跨仓隔离和跨回合确认门禁继续保留。旧 clarification
checkpoint/result 流程已成为 Historical，外部历史状态保持原样但不再支持。

开发与官方插件校验要求 Python 3.9 或更高版本，并需要 PyYAML：

```bash
python3 -m pip install -r requirements-dev.txt
```

## 安装

在 Marketplace 仓库根目录执行校验、注册本地 Marketplace 并安装插件：

```bash
python3 scripts/validate_all.py
codex plugin marketplace add "$(pwd)"
codex plugin add ai-native-devkit@ai-native-devkit
```

首次启用后，在 Codex 中打开 `/hooks`，审核并信任来自 `ai-native-devkit` 的 Hook。
信任按 Hook 内容 hash 保存；插件升级导致 Hook 内容变化时需要重新审核。信任后无需启动
后台服务，也无需逐任务开启 Trace。Hook 会收到 Codex 生命周期回调，但只有 DevKit Runtime
发出 `workflow.started` 激活当前 Session 后才持久化事件；没有使用本插件的 Session 不创建
Execution Trace。

卸载插件：

```bash
codex plugin remove ai-native-devkit@ai-native-devkit
```

## 用户决定优先

用户可以明确跳过整个阶段，也可以只忽略当前阻塞项。例如：

- “这次跳过 Design 和 Plan，按当前需求直接实现。”
- “忽略这个需求来源过期的问题，以当前代码为准继续设计。”
- “这次不跑测试，直接提交。”

AI 会通过 `workflow.user_decision` 记录本次决定并继续，不要求重复确认。
跳过阶段后，后续流程不再追要该阶段缺失的文档；只忽略阻塞项时，其余工作继续。
决定限定在当前仓库、流程和阶段尝试内。Trace 保留跳过、未执行和失败的实际结果，
不会伪造审批、Init 就绪状态或测试通过；最终可显示 `completed_with_exceptions`。
跳过 Verify 后，仍可用 `docs.classify` 检查真实文档影响；用户也跳过 Docs 时不会重新触发。
这些规则覆盖下文的默认流程门禁，且不改变工具自身的权限边界。

## 调用方式

使用 `$coding-sop` 处理完整研发任务，或者显式调用：

- `$sop-init`
- `$sop-clarify`
- `$sop-design`
- `$sop-plan`
- `$sop-execute`
- `$sop-debug`
- `$diagnosing-bugs`（内置的 Matt 调试方法；完整 Debug 流程通常通过 `$sop-debug` 调用）
- `$sop-verify`
- `$sop-sync-docs`

## 默认语言与快照范围

所有 Skill 默认使用简体中文交流并生成文档，包括标题、章节、正文、来源说明及实施计划。
用户明确指定语言时按其要求输出。代码标识符、命令、路径、JSON 字段和精确 Git 引用保持原样。
需求文档 Writer 默认生成中文标题与来源标签；显式英文请求可使用 `document_language: en`。
已有英文需求文档继续按原来的 commit/blob identity 读取，不会自动翻译或重写。

Init 的 `RepositoryRevision` 和需求写入的仓库保护快照不再枚举或读取无关未跟踪文件，
包括 `.gitignore` 忽略的依赖、缓存和构建产物。已暂存的新文件、已跟踪文件的修改与删除
仍参与快照校验；未跟踪文件不会计入原来的 64 MiB 内容哈希限制，也不会单独使修订变脏。
插件仍只提交目标需求文档。已跟踪的 Git 输出及明确引用的来源仍保留各自的大小与时间限制；
Init 和 Docs Sync 为实际文档变更记录的路径清单继续保留。

路由同时记录任务意图和流程强度，并保留旧 `route` 字段：

| 意图 / 强度 | 兼容 route | 场景 |
|---|---|---|
| `development + fast` | `lightweight` | 行为明确、局部、低风险 |
| `development + standard/strict` | `development` | 新行为、歧义、跨模块、架构或高风险变更 |
| `debug + fast/standard/strict` | `debug` | Bug、失败、回归或性能异常 |

## 开发流程与 Skill

`$sop-init` 先用内部 `scripts/init_cli.py` 只读检查 Git worktree，并在仓库外持久化
`InitReport`；只有上下文 ready 后，才进入现有 Docs Bootstrap / Adapt / Refresh 预览与审批。
如果 Docs 阶段实际写入仓库，它会在校验通过后创建一个新的只读 post-write context task，
下游只使用新的 `task_id` 和 report reference，避免沿用已过期的 pre-write revision。
初始请求可以使用 Codex task/thread ID 作为候选身份；如果该身份已绑定另一个明确选择的仓库，
CLI 会创建独立 Workflow Task 且不修改旧任务。显式 task ID 和所有 follow-up 仍严格校验目标。

同目录的 `AGENTS.md` / `CLAUDE.md` 不再要求整份文件字节一致：文档标题、正文空白、
列表标记、强调格式，以及对应的 `.Codex/start-rule.md` / `.claude/start-rule.md`
启动链接差异可以通过 Init；章节作用域、列表层级、代码及其他链接仍参与比较。
正文仍有差异时，AI 会说明相关文件、行号和规则片段，区分矛盾、补充规则和待确认信息，
并让用户选择本任务以哪份为准。选择绑定当前报告及两份文件的版本，可按目录分别处理；
文件变化后需重新确认，不会自动改写项目文件，也不会影响其他任务。

`$sop-clarify` 先检查项目状态、评估范围并在必要时拆分过大的请求，然后每条消息只问一个
聚焦于目的、约束或成功标准的问题。访谈完成前不写 clarification 文件或结构化 baseline。
完成后，`scripts/workflow_cli.py` 的 `requirements.write` 只提交一份最小 requirements 文档，
并返回精确的 `path`、`commit` 和 `blob_digest`。Runtime 以
`clarify.requirements` 请求该引用的审批，只有后续用户回合才能解决；`$sop-design` 在启动前
通过 `requirements.load` 加载同一已批准引用。内容或来源漂移会回到 Clarify，不会猜测替代物。

新的 Codex 会话只有在显式提供同一 `RequirementDocRef` 时才能复用已完成的精确审批；插件
不会仅凭仓库路径、聊天内容或历史文件猜测“最近需求”。不同 Workflow Task 不直接共享私有任务状态，只共享经
`$sop-sync-docs` 预览和批准后晋升的 canonical docs。

当前 development 流程为：

```text
$sop-init -> $sop-clarify -> $sop-design -> $sop-plan -> $sop-execute -> $sop-verify -> $sop-sync-docs
```

Current `$sop-plan` 把完整批准的 DesignDoc 翻译成详细 Markdown PlanDoc：它包含
设计约束、验收覆盖和顺序纵向切片，不创建 tracker ticket、依赖图或执行 frontier。
`$sop-execute` 固定一个 Git baseline，按切片串行完成行为优先实现和 focused/final
checks，创建一个 candidate commit，完成 Spec/Standards 双轴评审后返回
`ExecutionResult`。Verify、Docs Sync 和最终 `TaskOutcome` 仍由 `$coding-sop` 顶层流程负责。

Plan 启动后发现 design gap 会调用 `stage.fail(plan.design_gap)`，不会继续 Execute。
Execute 发现任何预先存在的 staged、unstaged 或 untracked 变更时，必须为整份 PlanDoc
创建一个干净隔离工作区；不能隔离则返回 blocked 并终止该 run。所有适用 final
`Expected` 都是 candidate commit 前的硬门禁，candidate 变化后必须重新通过。Execute 的
`blocked | failed | replan_required` 都调用 `stage.fail`；只有 `completed` 才允许顶层流程进入
Verify、Docs Sync 和 `workflow.finish`。

PlanDoc 正文只出现在任务响应，或在仓库已经 ignore 对应路径时保存为
`.scratch/ai-native-devkit/tasks/<task_id>/plan.md` 的可选视图。Runtime 可绑定调用者提供的
算法限定 digest identity，但不写入、加载或独立计算 PlanDoc 内容，也没有持久 per-slice
cursor。跨会话 PlanDoc 选择和执行恢复仍是 Planned V1。

`$sop-debug` 是薄生命周期适配器：它启动 Debug run，自动调用插件内置的
`$diagnosing-bugs` 完成反馈回路、根因定位、回归测试和聚焦修复，再结束 Debug run 并调用
`$sop-verify`。用户无需另外安装 Matt Skills；直接调用 `$diagnosing-bugs` 只运行调试方法，
不包含 DevKit Runtime、Verify 和 Docs Hook 链路。

## 自动 Execution Trace

插件中的 `hooks/hooks.json` 监听 Session、Turn、Tool、Permission、Compact、Subagent 和
Stop 生命周期。`scripts/trace_collector.py` 自动把 Codex Hook 输入转换为完整、追加写入的
事实事件，但在插件工作流激活前保持无写入；普通 Codex 任务不会生成 Trace。首次调用
DevKit Runtime 时由代码发出 `workflow.started`，随后才记录该插件工作流的 Host 与 Runtime
事实；Agent 不启动、不更新也不结束 Trace。`scripts/init_cli.py` 在 Init Phase 1
上下文检查状态提交后自动发出阶段、结果和审批事实；路由、验证、Docs 等工作流状态由 `scripts/runtime_cli.py` 在对应
代码边界发出。两条路径都使用 `devkit_runtime`，失败时只标记 Trace，不改变原任务结果。

ID 关系固定为：

```text
session_id 1 : 1 trace_id
trace_id   1 : N turn_id
turn_id    1 : N event_id
```

默认记录位于：

```text
~/.codex/state/ai-native-devkit/v1/execution-traces/<trace_id>/
├── metadata.json
├── events.jsonl
└── summary.json
```

`events.jsonl` 每行是完整事件；`summary.json` 是确定性投影。Trace 不保存完整提示词、
完整回复、原始命令/工具输出、源码、凭证、隐藏思考或人工评测真值。采集失败不阻塞原任务；
错误指纹写入 `execution-traces/collector-errors.jsonl`，相关 Trace 标记为 `partial`。

每个 SOP 阶段运行都有代码生成的 `stage_run_id`，记录 `started` 和
`completed | skipped | failed` 的时间；重试保留为新的运行记录。Clarify、Design、Plan
确认通过同一阶段下成对的 `approval.requested/resolved` 和 `approval_id` 关联，不记录确认
原文。Design/Plan 可同时携带调用者提供的文档 digest identity；Runtime 只验证阶段间
identity 一致，不保存或重建 DesignDoc/PlanDoc。Init 会复用正常的初始化扫描和文档校验，自动记录识别、新增、覆盖、保留、删除和
冲突路径，不要求 Agent 额外总结日志，也不会向用户展示内部路由状态。
路线明确不适用的阶段可直接记录为 `skipped`，不能代替路线中的必需阶段。
工作流完成还会经过代码门禁：所选路线的必需阶段必须按顺序结束，Clarify/Design/Plan
确认必须绑定对应阶段，Verify 必须通过，Docs 动作必须已解决；否则不会写入
`workflow.completed`。Docs Sync 的实际变更路径由私有前后快照自动得出。
完成后的同一 Codex Session 若继续普通问答，不会追加到已结束的插件 Trace；SessionEnd
回退也只恢复插件工作流时间窗口内的缺失事实。

查看当前 Session 的结构化记录可调用 `runtime_cli.py` 的 `trace.load`；直接排查文件时，从
`metadata.json` 的 `session_id` 找到对应 Trace 目录即可。

## 自动 Docs Hook

`$sop-verify` 把新鲜验证结果提交到 `runtime_cli.py` 的 `verification.complete`。只有验证通过
才会在同一个程序调用中触发 Docs Hook。Hook 从 Git baseline、HEAD、工作区和未跟踪文件
自动得到 changed paths，然后输出 `NO_CHANGE`、`DETERMINISTIC`、`SEMANTIC_REVIEW` 或
`CONFLICT`。路由事件同时记录经过校验的 `change_kind`，用于把
`test`、`refactor` 和 `temporary` 与真正的功能/契约变化区分开。

普通 Bug、测试补充、内部重构和临时状态仍会经过后台的低成本分类，但结果为
`NO_CHANGE`，不写文档，也不询问用户。语义文档修改必须先给出完整预览并取得确认。
Docs Hook 不生成 Handoff 建议，也不读取或修改 `handoff/`。

## 文档边界

`docs/` 是面向 Agent 的项目知识。Handoff 接手文档由用户自行管理；插件不再提供
相关 Skill、模板、扫描、迁移提示、审批或路径拦截，也不询问是否更新。Init 与 Docs Sync
继续排除这些文档，已有内容保持原样。旧 Trace 中的 `handoff.*` 事件及
`summary.handoff_actual_result` 仅保留读取兼容；不再产生新的 Handoff 活动。

受支持的任务请求、状态转换、Init 报告和证据写入仓库外 TaskStateStore，不直接污染 canonical docs。
完成的 clarification requirements 写入 `docs/superpowers/requirements/` 并保留精确 Git
identity；它们是 workflow records，不是 canonical CurrentState。适合跨任务复用的批准决策
可经完整语义预览晋升到 `docs/decisions/`，并保留精确 requirement Git provenance。

## 本地开发更新

修改本地插件源码后，更新缓存标识并重新安装：

```bash
python3 "${CODEX_HOME:-$HOME/.codex}/skills/.system/plugin-creator/scripts/read_marketplace_name.py" \
  --marketplace-path .agents/plugins/marketplace.json
python3 "${CODEX_HOME:-$HOME/.codex}/skills/.system/plugin-creator/scripts/update_plugin_cachebuster.py" \
  plugins/ai-native-devkit
codex plugin add ai-native-devkit@ai-native-devkit
```

Cachebuster 只用于本地开发；正式版本使用干净 SemVer。重新安装后应在新 Codex 任务验证更新。

## 当前验证范围

Current 0.4.0：Clarify 产出 Git requirements 记录，Design 只读取显式的已批准精确引用。

- `python3 scripts/validate_all.py` 运行单元、契约、集成和插件结构校验。
- S0 runtime 覆盖 Artifact contract、TaskStateStore 原子性/幂等/并发/损坏拒绝、持久化安全、
  Git repository inspection 与 init CLI。
- Requirement runtime 覆盖最小文档、单文件 Git commit、脏工作区保护、SHA-1/SHA-256、
  精确 approval subject、修改后失效、跨会话精确引用、来源漂移和 Design 加载门禁。
- Execution Trace 覆盖完整事件结构、1:1 Session 映射、并发追加、脱敏、Host/Runtime 来源、
  捕获状态、跨进程 Hook CLI 和确定性 summary。
- Docs Hook 覆盖 Git changed paths、验证后自动触发、普通变更静默、语义确认信号，以及不产生 Handoff 联动。
- 10 个 Skill 的发现与静态契约、官方插件包结构，以及中文 Docs 模板、五篇固定
  Overview 文档、四篇受管平台 Runbook、symlink 安全预检、managed-doc 分类器、决策晋升
  元数据和只读校验器均受回归测试保护。
- 新 Codex 任务已经验证 `$coding-sop` 路由和 `$sop-init` 只读 Bootstrap 预览；
  完整开发链和 Debug 链仍需要增加独立的场景化行为评测。

## 0.4.0 版本边界

`0.4.0` 用最小 Git requirements 文档、精确 Trace 审批和
`RequirementDocumentLoader` 替换 0.2/0.2.3 的 clarification checkpoint/result 流程。
Clarify 不持久化未完成访谈，也不建立结构化 baseline；Design 只接受显式已批准的精确
`RequirementDocRef`。旧外部状态不迁移、不删除，但不再是受支持输入。

## Historical 0.3.0 版本边界

`0.3.0` 删除 0.2.x 的错误 EvaluationTrace 记录、oracle 字段、评测汇总和 Agent 日志步骤，
改为 Codex Collector Hook 与 DevKit Runtime 双来源的自动事实流，并加入验证通过后自动触发的
Docs Hook。该能力仍是本地开发观测，不是生产遥测。`0.2.3` 的 Init caller identity 跨仓隔离和
Init 后续用户回合确认边界继续保留。Current PlanDoc 与 `ExecutionResult` 由 Agent 按
prompt Skill 契约产生，尚未成为完整的
持久化 WorkflowRuntime。Planned V1 不再以公开任务图、集中执行台账、tracker frontier
或并发 slice scheduler 为目标；跨会话 PlanDoc 选择和持久 cursor/recovery 仍待设计。
DesignResult、完整审查/验证报告和通用 Docs Sync 仍是后续结构化运行时工作。自动风险评分、Cooper adapter、
managed knowledge packs、完整自动 WorkflowRuntime、Codex Cloud 与 ChatGPT Web 也仍是后续规划。

完整的 Current / Implemented / Planned 划分见仓库 `docs/`。第三方来源和许可见
[`THIRD_PARTY_NOTICES.md`](./THIRD_PARTY_NOTICES.md)。

## 设计来源与致谢

研发流程借鉴 [Superpowers](https://github.com/obra/superpowers) 的阶段化交付方法，并参考
[Matt Pocock Skills](https://github.com/mattpocock/skills) 的调试反馈回路、行为测试、任务拆分和
评审思想。AI Native DevKit 在此基础上加入持久化状态、显式 ArtifactRef、Docs 状态分层、受控
决策晋升和项目文档边界。
