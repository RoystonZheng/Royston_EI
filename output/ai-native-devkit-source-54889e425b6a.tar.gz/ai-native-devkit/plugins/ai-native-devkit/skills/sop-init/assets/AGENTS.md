# 项目协作规则

## 项目文档

项目上下文统一存放在 `docs/`。开始开发、设计、联调、排障或接手任务前，先根据下面的目录索引选择需要读取的文档。

### 阅读规则

1. 先阅读本文件中的 docs 目录说明和任务场景。
2. 进入某个 docs 子目录前，必须先读取该目录的 `README.md`。
3. 根据子目录 README 的文件索引，按需读取具体文档。

### docs 目录索引

| 目录入口 | 内容 | 什么时候读取 |
|---|---|---|
| `docs/overview/README.md` | 项目目标、业务模型、架构、技术栈和实现状态 | 接手项目、继续任务或确认现状 |
| `docs/references/README.md` | PRD、设计稿和外部资料 | 开发新需求或确认上游约束 |
| `docs/decisions/README.md` | 已确定的关键决策和原因 | 修改架构或重要业务规则 |
| `docs/design/README.md` | 各模块的长期设计 | 开发或修改具体模块 |
| `docs/api/README.md` | 后端接口和前端消费契约 | 修改接口或进行联调 |
| `docs/runbooks/README.md` | 启动、验证、部署和排障步骤 | 执行操作或排查问题 |
| `docs/pitfalls/README.md` | 已确认的常见问题 | 排障或遇到重复问题 |
| `docs/superpowers/README.md` | 版本化 requirements、specs 和 plans 工作记录 | 仅通过精确引用读取或用于追溯 |

### 文档更新规则

- 新增、删除或重命名文档时，更新所在目录的 `README.md`。
- 新增 docs 子目录或改变目录职责时，更新本文件的目录结构和索引。
- 普通新增文件没有跨目录影响时，不需要修改其他目录。

### 插件协作规则

- 任务改变长期项目知识时，使用 `$sop-sync-docs` 判断并同步 `docs/`。
- 从已批准的需求工作记录晋升 ADR 时，来源必须记录为精确的
  `source_requirement_path`、`source_requirement_commit` 和
  `source_requirement_blob_digest`；不得把 requirements、specs 或 plans 工作记录当作
  CurrentState。
- 项目根目录的 `handoff/` 是面向研发人员的派生接手地图，不属于 `docs/`。
- Handoff 接手文档由用户自行管理；插件不检查、询问、迁移或更新它们。
