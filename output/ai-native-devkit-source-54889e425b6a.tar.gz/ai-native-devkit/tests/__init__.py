"""Coding SOP plugin tests."""
