"""Module behavior tests."""
