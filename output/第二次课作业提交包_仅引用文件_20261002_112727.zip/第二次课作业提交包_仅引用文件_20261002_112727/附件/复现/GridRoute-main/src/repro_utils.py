from __future__ import annotations

import ast
import heapq
import math
from pathlib import Path
from typing import Any, Iterable

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def load_table(path: str | Path) -> pd.DataFrame:
    """Load either CSV or Excel input using the file extension."""
    path = Path(path)
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path, encoding="utf-8-sig")
    return pd.read_excel(path)


def parse_literal(value: Any, default: Any = None) -> Any:
    if value is None:
        return default
    if isinstance(value, float) and math.isnan(value):
        return default
    if isinstance(value, str):
        try:
            return ast.literal_eval(value)
        except (ValueError, SyntaxError):
            return default
    return value


def as_int(value: Any) -> int:
    return int(round(float(value)))


def parse_path(value: Any) -> list[tuple[int, int]]:
    raw = parse_literal(value, [])
    if not isinstance(raw, (list, tuple)):
        return []

    path: list[tuple[int, int]] = []
    for point in raw:
        if not isinstance(point, (list, tuple)) or len(point) != 2:
            return []
        try:
            path.append((as_int(point[0]), as_int(point[1])))
        except (TypeError, ValueError):
            return []
    return path


def _point(value: Any) -> tuple[int, int] | None:
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        return None
    try:
        return as_int(value[0]), as_int(value[1])
    except (TypeError, ValueError):
        return None


def obstacle_coords_from_row(row: pd.Series) -> set[tuple[int, int]]:
    """Read expanded obstacle cells from a dataset/reference row."""
    raw = row.get("all_obstacle_coords")
    if raw is not None:
        parsed = parse_literal(raw, [])
        coords = {_point(item) for item in parsed if _point(item) is not None}
        if coords:
            return coords

    # API output may only contain rectangle definitions.
    rectangles = parse_literal(row.get("obstacles"), [])
    coords: set[tuple[int, int]] = set()
    for rectangle in rectangles:
        if not isinstance(rectangle, dict):
            continue
        top_left = _point(rectangle.get("top_left"))
        bottom_right = _point(rectangle.get("bottom_right"))
        if top_left is None or bottom_right is None:
            continue
        for x in range(top_left[0], bottom_right[0] + 1):
            for y in range(top_left[1], bottom_right[1] + 1):
                coords.add((x, y))
    return coords


def dijkstra_path(
    matrix_size: int,
    obstacle_set: set[tuple[int, int]],
    start: tuple[int, int],
    end: tuple[int, int],
) -> list[tuple[int, int]]:
    """Shortest cardinal-move path on a finite grid."""
    if start in obstacle_set or end in obstacle_set:
        return []

    queue: list[tuple[int, tuple[int, int]]] = [(0, start)]
    visited: set[tuple[int, int]] = set()
    parent: dict[tuple[int, int], tuple[int, int] | None] = {start: None}
    moves = ((0, 1), (1, 0), (0, -1), (-1, 0))

    while queue:
        cost, current = heapq.heappop(queue)
        if current in visited:
            continue
        visited.add(current)

        if current == end:
            path: list[tuple[int, int]] = []
            cursor: tuple[int, int] | None = current
            while cursor is not None:
                path.append(cursor)
                cursor = parent[cursor]
            return path[::-1]

        for dx, dy in moves:
            neighbor = (current[0] + dx, current[1] + dy)
            if not (0 <= neighbor[0] < matrix_size and 0 <= neighbor[1] < matrix_size):
                continue
            if neighbor in obstacle_set or neighbor in visited:
                continue
            if neighbor not in parent:
                parent[neighbor] = current
            heapq.heappush(queue, (cost + 1, neighbor))

    return []
