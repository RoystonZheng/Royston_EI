# -*- coding: utf-8 -*-
"""端到端执行 aifp_planner.ipynb:按顺序提取并运行全部代码 cell,保存输出图。

说明:不使用 nbconvert(其依赖 tornado 在本机有 Windows 证书库 SSL 兼容问题),
直接 exec 各 cell 源码,执行语义与 Jupyter 中"Run All"一致。
"""
import os

import matplotlib
matplotlib.use("Agg")
import nbformat

ROOT = os.path.dirname(os.path.abspath(__file__))
NB_PATH = os.path.join(ROOT, "src", "aifp_planner.ipynb")
OUT_DIR = os.path.join(ROOT, "results", "repro")

os.makedirs(OUT_DIR, exist_ok=True)
nb = nbformat.read(NB_PATH, as_version=4)

ns = {"__name__": "__main__"}
for idx, cell in enumerate(nb.cells):
    if cell.cell_type != "code":
        continue
    print(f"--- 执行 cell {idx} ---")
    exec(compile(cell.source, f"<cell {idx}>", "exec"), ns)

# 保存 notebook 最后一张图 (cell 3 的路径规划结果)
import matplotlib.pyplot as plt  # noqa: E402
fig = plt.gcf()
fig_path = os.path.join(OUT_DIR, "aifp_planner.png")
fig.savefig(fig_path, dpi=150, bbox_inches="tight")
print(f"\nnotebook 全部 cell 执行成功, 路径图已保存: {fig_path}")
