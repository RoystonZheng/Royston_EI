# NYC EV v2 offline fixed-assignment energy recalculation

Source run: fixed_assignment_energy_recalc_v2_20261027T1542; status completed_with_expected_gaps; created 2026-10-27T15:42:21+08:00.
Scope: post-hoc energy accounting for saved, complete dispatch assignments; no policy rerun or model calls.
Included outputs: 91/630 expected method results across 13/90 completed paired cells; 539 expected method result files are not yet available.
Energy profile: ev_longitudinal_v2 / generic_reference_ev_v1; recalculation script SHA-256 e15bea9197790c24830f230c8279e0ee4038e62c318c48c487ded6d4b9c1dab3.
This is an offline accounting sidecar. It does not rerun or alter dispatch decisions and is not a completed matrix result.
Each source file hash is in MANIFEST.tsv; the integrity audit is preserved.
