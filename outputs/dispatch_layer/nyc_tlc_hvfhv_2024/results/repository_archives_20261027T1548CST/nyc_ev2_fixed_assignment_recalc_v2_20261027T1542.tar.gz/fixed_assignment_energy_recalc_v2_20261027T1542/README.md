# NYC EVv2 fixed-assignment pickup-energy recalculation v2

This sidecar reconstructs energy for assignments already selected in the source result files. It makes no model calls and does not change any assignment or service metric.

The original online `summary.total_energy_kwh` is reproduced by replaying the saved assignments with the original empty pickup edge sequence and the frozen EVv2 profile. The corrected sidecar then adds a synthetic flat virtual pickup segment with the saved zone-centroid proxy distance and duration, 0 kg passenger load, no signal delay, and missing grade treated as flat by the EVv2 integrator. The proxy uses the frozen scenario's 5 m/s policy; it is an estimate, not a measured road trajectory or vehicle telemetry.

The integrity audit verifies source hashes, result hashes, profile hashes, assignment-pair identity, online-energy reconciliation, pickup trace basis, and the corrected-energy component identity. The manifest reports `completed_with_expected_gaps`: it includes the 91 result files present at this checkpoint, while 539 method results remain absent from the planned 90-cell matrix.

The summed energy totals in `integrity_audit_v2.json` are across method-run files and must not be interpreted as one fleet or citywide total. Methods D1, D2, D5, D6, D7 and D8 expose candidate energy to an optimizer or the LLM, so their old selections remain affected by the missing pickup component. D0 does not use energy in its assignment rule; its saved assignments can be retained while using this corrected energy sidecar. This recalculation does not repair decisions made under the incomplete energy input.
