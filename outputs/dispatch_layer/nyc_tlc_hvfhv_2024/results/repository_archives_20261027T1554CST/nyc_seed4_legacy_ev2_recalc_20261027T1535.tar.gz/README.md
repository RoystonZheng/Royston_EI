# nyc_seed4_legacy_ev2_recalc_20261027T1535

Source path: dispatch_formal_multimonth_energy_v2_offline_20261027_seed4_legacy_v1
Status: completed_with_expected_gaps; created 2026-10-27T15:35:22+08:00.
Included outputs: 460; expected method results still missing: 170.
This is a partial offline accounting checkpoint. No model calls or policy reruns occurred; it does not retroactively change dispatch choices.
This seed/protocol remains separate from the official EV v2 seed0 run and from other replicates.
The bundle contains the manifest, integrity audit, indexes, output files, and source README/checksum ledger. Per-file checksums are in MANIFEST.tsv
