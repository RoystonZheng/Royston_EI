# NYC EVv2 fixed-assignment pickup-energy recalculation v2

This sidecar reconstructs energy for assignments already selected in the source result files. It makes no model calls and does not change any assignment or service metric.

The original online EVv2 total is reproduced using the saved assignments and original empty pickup edge sequence. The corrected sidecar adds a synthetic flat virtual pickup segment using the saved zone-centroid proxy distance and duration, 0 kg passenger load, no signal delay, and missing grade treated as flat by the EVv2 integrator. The proxy follows the frozen 5 m/s scenario policy; it is an estimate, not a measured road trajectory or vehicle telemetry.

integrity_audit_v2.json verifies source hashes, output hashes, profile hashes, assignment-pair identity, online-energy reconciliation, pickup trace basis, and corrected-energy component identity. The manifest reports completed_with_expected_gaps: it includes the result files present at this checkpoint; the planned 90-cell matrix remains incomplete.

Summed energy totals are across method-run files and are not one fleet or citywide total. Methods D1, D2, D5, D6, D7 and D8 expose candidate energy to an optimizer or the LLM, so their old selections may be affected by the missing pickup component. D0 does not use energy in its assignment rule; it can retain its original selection while using the corrected energy metric. This recalculation does not repair any decision made under the incomplete online feature.
