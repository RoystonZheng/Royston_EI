# nyc_ev2_fixed_assignment_recalc_1545

Source path: dispatch_formal_ev2_lexicographic_v2_20261027/fixed_assignment_energy_recalc_v2_20261027T1545
Status: completed_with_expected_gaps; created 2026-10-27T15:46:35+08:00.
Included outputs: 92; expected method results still missing: 538.
This is a partial offline accounting checkpoint. No model calls or policy reruns occurred; it does not retroactively change dispatch choices.
This seed/protocol remains separate from the official EV v2 seed0 run and from other replicates.
The bundle contains the manifest, integrity audit, indexes, output files, and source README/checksum ledger. Per-file checksums are in MANIFEST.tsv
