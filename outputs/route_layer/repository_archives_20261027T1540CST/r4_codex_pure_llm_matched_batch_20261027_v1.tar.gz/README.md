# R4 同端点 Codex 纯 LLM 整路线对照

状态：129项可路由任务全部进入终态，最终审计已完成。

## 冻结设置

- 150项总任务中，129项通过路线搜索预检，21项按冻结规则跳过。
- 模型：`gpt-5.6-luna`，reasoning effort `low`；每个可路由任务一次整路线提议。
- 起点、接客点、送达点固定为同一R4预检端点；使用相同本地validator和EV longitudinal v2路线评估器。
- 不重试、不修补路线、不回退到传统搜索；失败和未知投递都留在129项分母。

## 最终结果

- validator接受的完整路线：0/129。
- 122项有完整模型usage，其中109项模型返回无法通过的结果，13项路线提议被validator拒绝。7项投递或usage未知；没有重发。
- 122项累计输入2,247,448 tokens（缓存674,560为输入子集）、输出115,114 tokens。7项未知调用的tokens未计入。
- usage完整调用的费率卡估算：11.655140 Standard credits，API等价约$0.466206。Codex CLI未报告账户实扣；账户周窗口前后显示39%，不是该实验单独的费用。
- 失败明细：104项`unable_to_construct_route`、4项`no_directed_path`、1项模型自报失败但未给原因；13项提议被逐边validator拒绝。

该组没有任何通过validator的完整路线，因此路线距离、行驶时间和能耗的配对差异不可估计。结果可作为本批次指定模型、提示和单次整路线协议的基线记录，不能推广到所有纯LLM方法。

## 审计与复现文件

- `final_audit.json`：完整分母、结果、token、费率估算、未知项与完整性核验。
- `outcome_breakdown.csv`、`model_failure_breakdown.csv`、`unknown_delivery_tasks.csv`：可复核的结果分解。
- `manifest.json`、`tasks/seed_*/<task_id>/`：冻结任务、prompt、attempt、逐项validator与CLI traces。
- `usage_checkpoints.jsonl`：账户窗口读数；`SHA256SUMS`：所有批次产物的哈希。
