# Completed R4 matched pure-LLM baseline

The manifest marks all 129 routeable tasks terminal: 0/129 valid complete routes, 7 unknown outcomes, 122 requests with complete usage. This is a baseline for the specified one-shot protocol, not a claim about all pure-LLM systems. Its stale lock/PID files are not packaged.

This archive contains the files listed in `ARCHIVE_MANIFEST.tsv`. Lock/PID files, caches, `.git` data, and temporary files are excluded. Each archived file was checked against its source hash before packaging and rechecked after decompression. No credential patterns were found.
