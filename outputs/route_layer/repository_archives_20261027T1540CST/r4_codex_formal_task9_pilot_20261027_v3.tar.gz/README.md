# Completed R4 task9 formal pilot

This is a completed single-task pilot with preserved audit versions; it is not the formal 129-task matrix or a population-level result.

This archive contains the files listed in `ARCHIVE_MANIFEST.tsv`. Lock/PID files, caches, `.git` data, and temporary files are excluded. Each archived file was checked against its source hash before packaging and rechecked after decompression. No credential patterns were found.
