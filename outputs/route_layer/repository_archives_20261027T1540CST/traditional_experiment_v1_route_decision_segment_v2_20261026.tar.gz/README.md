# Route decision segment-v2 offline audit

This sidecar covers 20 source files, 150 tasks, and 450 method/task decisions. It does not change source results or rerun a route search. Fare is missing, so no net-cash choice is claimed; read `audit.json` for exact candidate, blocked, and unevaluated counts.

This archive contains the files listed in `ARCHIVE_MANIFEST.tsv`. Lock/PID files, caches, `.git` data, and temporary files are excluded. Each archived file was checked against its source hash before packaging and rechecked after decompression. No credential patterns were found.
