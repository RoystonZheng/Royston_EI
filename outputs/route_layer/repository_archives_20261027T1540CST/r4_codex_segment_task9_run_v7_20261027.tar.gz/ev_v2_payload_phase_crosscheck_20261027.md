# R4 EV v2 载荷分段离线复核

复核时间：2026-10-27 15:09 CST。该文件只读重算已落盘路线，不发模型请求、不重跑仿真。能耗是通用参考车辆的 EV v2 仿真估值，不是实车遥测；未知电价或票价时现金费用留空。

- 计算工件：`ev_v2_payload_phase_crosscheck_20261027.json`，SHA-256 `381073cde1fd9d69cdaa8474aaf3c61a4d040851c00be695d8636ee09763fe8a`。
- 模型与配置：`ev_longitudinal_v2`，profile `generic_reference_ev_v1`，SHA-256 `b4878499ec45879552a35f56978cedcfeb78df4ab841a3514ec1741833eb7bee`。
- 地图：`outputs/route_layer/map_generation/map_100x100_seed_0.json`，SHA-256 `bdf7da792ecf78ae393f5441055d592f3585674bea48d4f12d2d2d1ce632adbe`；共 36,602 条边，含坡度字段的边为 0 条，故按平坡处理并报告坡度缺失限制。
- 载荷约定：接驾空驶 0 kg；pickup 后载客腿 75 kg；pickup 处切分，不计额外乘客上下车停靠时间。
- EV v2 在路线原始终审中的旧字段是全程 75 kg 口径。下表的“分段重算”来自独立 sidecar，保留原始审计文件不被改写。
- 独立复算：从冻结地图和原始路线边序列重新调用 `route_experiment.costs.evaluate_route_candidate`，正式任务、同端点Dijkstra、pilot、v7和v6前缀均与下表/JSON差值小于 1e-12；验证JSON为 `ev_v2_payload_phase_independent_recalculation_20261027.json`，SHA-256 `753c25c3fb467ff0450af50a44202f6f4f3438ad7c1c3d5d0faeb423c15b2368`。原crosscheck记录的辅助生成脚本SHA为 `566b7f1746d68f282cd07a49dc3c55d810ecc740a3762d6abf1f9867097831e2`，15:18 CST独立复算时脚本SHA为 `5cd42dd089e5965c49b463b819a51606dc1a64298d963b729aa30767f64f0cbf`，二者因后续源码变化不一致；该辅助脚本哈希不作为数值复算的唯一依据，独立复算使用的 `costs.py`、`energy_model.py` 和 `models.py` 哈希已单独列出。

| 样本 | 距离 | 分段模拟时间 | 空驶段能耗（0 kg） | 载客段能耗（75 kg） | 合计 EV v2 能耗 | 旧全程75 kg值 |
|---|---:|---:|---:|---:|---:|---:|
| R4 formal task-0000-0001 | 11.8 km | 1406.458 s | 0.821262 kWh | 0.489480 kWh | 1.310741 kWh | 1.318951 kWh |
| 同端点 Dijkstra task-0000-0001 | 9.6 km | 1024.759 s | 0.598939 kWh | 0.470496 kWh | 1.069435 kWh | 1.071982 kWh |
| R4 formal task-0000-0002 | 17.1 km | 2059.220 s | 0.690169 kWh | 1.369574 kWh | 2.059743 kWh | 2.065772 kWh |
| 同端点 Dijkstra task-0000-0002 | 14.5 km | 1556.920 s | 0.661761 kWh | 1.020759 kWh | 1.682520 kWh | 1.688110 kWh |
| R4 fresh task9 准入 pilot | 11.3 km | 1263.269 s | 0.771016 kWh | 0.503313 kWh | 1.274330 kWh | 1.286286 kWh |
| R4 task9 independent v7诊断 | 21.7 km | 3016.204 s | 2.191839 kWh | 0.494111 kWh | 2.685949 kWh | 2.734922 kWh |

对同端点基线的单任务差异，task-0000-0001 的 R4 距离、模拟时间、分段能耗分别高 22.9%、37.2%、22.6%；task-0000-0002 分别高 17.9%、32.3%、22.4%。仅是两项个案，不代表总体排序。

独立复算详情见 [EV v2独立分段复算JSON](ev_v2_payload_phase_independent_recalculation_20261027.json)。

## 未完成前缀和拒绝提案

- v6 仅到达 pickup 之前：128 条合法边、12.8 km、1874.830 s；旧全程75 kg估值 1.643219 kWh，按空驶0 kg更正为 1.601097 kWh。它不是完整路线。
- v7 独立诊断完成路线：217 条边、86次请求，分段估值 2.685949 kWh；不属于 R4 formal 分母。
- v7 对 58 个拒绝 proposal 均留有 EV v2 反事实能耗记录：48 个包含可映射的首个拒绝动作，10 个只估计此前合法前缀；失败原因标签计数为 progress_budget_exceeded 35、node_revisited 11、one_way_direction 10、remaining_route_unreachable 2。9 个 `attempted_prefix_energy` 为空是首步即拒绝，proposal 侧车另有记录。拒绝路线从未执行，其能耗不可视作实际耗电，也不可跨 proposal 求和。

## 决策函数一致性

本复核没有改变任何选择目标：R4 仍按 `travel_time_then_distance` 选择方向，EV v2仅作事后评价；Porto 仍分别运行 `FASTEST` 与 `LOWEST_ENERGY` 路线目标；NYC 仍按 `nyc_dispatch_decision_contract_v2` 分方法执行，D1/D2/D6/D7/D8 使用EV v2词典序能耗项，D0不优化能耗，D5仅将能耗作为模型输入。三个分支的道路表示和任务不可混合。`route_time_money_segment_v3_billable_net_energy` 规定单段费用以正净耗能计价、票价只计一次；在缺电价/票价或完整可行候选集时不填零费用，也不把它描述为已用于当前路线选择。
