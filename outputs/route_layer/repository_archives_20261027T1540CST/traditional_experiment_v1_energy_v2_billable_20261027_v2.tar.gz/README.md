# EV v2 billable recalculation

20 seed/objective source result files; 390/450 route-method pairs are evaluated and 60 remain unevaluated. This is an offline calculation over frozen route choices; no route algorithm was rerun. Route structure hashes match before and after. It is a partial supported sidecar, not a new route performance experiment.

This archive contains the files listed in `ARCHIVE_MANIFEST.tsv`. Lock/PID files, caches, `.git` data, and temporary files are excluded. Each archived file was checked against its source hash before packaging and rechecked after decompression. No credential patterns were found.
